/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simulacroparcial;

import controlador.ControladorSP;
/**
 *
 * @author DavidSJ
 */
public class SimulacroParcial {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ControladorSP controlador = new ControladorSP();
        controlador.iniciarJuego();
    }  
    
}
